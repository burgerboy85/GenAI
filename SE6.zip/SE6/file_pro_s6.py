import os
import json
import datetime
import pandas as pd

def calculate_age(dob: str, message_time: str) -> int:
    try:
        dob_dt = datetime.datetime.strptime(dob, "%Y%m%d")
        msg_dt = datetime.datetime.strptime(message_time[:8], "%Y%m%d")
        return msg_dt.year - dob_dt.year - ((msg_dt.month, msg_dt.day) < (dob_dt.month, dob_dt.day))
    except Exception:
        return None

def parse_hl7_message(msg: str) -> list:
    """
    Parse a single HL7 message and return a list of observation dicts.
    Returns empty list if OBX present without OBR.
    Uses list comprehension for better concurrency compatibility.
    """
    lines = [line.strip() for line in msg.split('\n') if line.strip()]
    segments = {}
    for line in lines:
        seg = line.split('|', 1)[0]
        segments.setdefault(seg, []).append(line)
    # OBX present without OBR: invalid
    if 'OBX' in segments and 'OBR' not in segments:
        return []
    if 'PID' not in segments or 'MSH' not in segments:
        return []
    pid = segments['PID'][0].split('|')
    msh = segments['MSH'][0].split('|')
    patient_id = pid[3]
    name_fields = pid[5].split('^')
    last, first, middle = (name_fields + ["", ""])[:3]
    dob = pid[7]
    gender = pid[8]
    address = pid[11]
    message_time = msh[6]
    lab_id = msh[10]
    obx_segments = segments.get('OBX', [])

    def build_record(fields):
        obs_id = fields[3]
        obs_name = obs_id.split('^')[1] if '^' in obs_id else obs_id
        value = fields[5]
        units = fields[6]
        ref_range = fields[7]
        obs_time = fields[14] if len(fields) > 14 else message_time
        return {
            "labId": lab_id,
            "messageTime": message_time,
            "patientId": patient_id,
            "fullName": ' '.join([first, middle, last]).strip().replace('  ', ' ').upper(),
            "firstName": first.upper(),
            "middleName": middle.upper(),
            "lastName": last.upper(),
            "dob": dob,
            "gender": gender,
            "age": calculate_age(dob, message_time),
            "address": address,
            "testCode": obs_id,
            "testName": obs_name,
            "value": value,
            "units": units,
            "referenceRange": ref_range,
            "observationTime": obs_time
        }

    # Use list comprehension for concurrency-friendly processing
    records = [build_record(obx.split('|')) for obx in obx_segments]
    return records

def parse_hl7_to_dataframe(filepath: str) -> pd.DataFrame:
    """Parse HL7 file into DataFrame, skipping invalid messages."""
    with open(filepath, 'r') as f:
        content = f.read().strip()
        messages = content.split('\n\n') if '\n\n' in content else [content]
        all_records = []
        for msg in messages:
            records = parse_hl7_message(msg)
            all_records.extend(records)
        df = pd.DataFrame(all_records)
        if not df.empty:
            df['value'] = pd.to_numeric(df['value'], errors='coerce')
        return df

def store_json_s3_style(row: pd.Series, base_dir: str = "instrument-data") -> str:
    """
    Store JSON object in S3-like folder structure, idempotently.
    """
    dt = datetime.datetime.strptime(row['messageTime'][:8], "%Y%m%d")
    path = os.path.join(base_dir, row['labId'], f"{dt.year:04d}", f"{dt.month:02d}", f"{dt.day:02d}")
    os.makedirs(path, exist_ok=True)
    filename = f"{row['patientId']}_{row['messageTime']}.json"
    full_path = os.path.join(path, filename)
    if os.path.exists(full_path):
        return full_path  # Idempotency: don't overwrite
    data = {
        "labId": row['labId'],
        "messageTime": row['messageTime'],
        "patient": {
            "patientId": row['patientId'],
            "fullName": row['fullName'],
            "firstName": row['firstName'],
            "middleName": row['middleName'],
            "lastName": row['lastName'],
            "dob": row['dob'],
            "gender": row['gender'],
            "age": row['age'],
            "address": row['address']
        },
        "observations": [{
            "testCode": row['testCode'],
            "testName": row['testName'],
            "value": row['value'],
            "units": row['units'],
            "referenceRange": row['referenceRange'],
            "observationTime": row['observationTime']
        }]
    }
    with open(full_path, 'w') as f:
        json.dump(data, f, indent=2)
    return full_path

def aggregate_average_observation_per_test_per_lab(df: pd.DataFrame) -> pd.DataFrame:
    return df.dropna(subset=['value']).groupby(['labId', 'testName'], as_index=False)['value'].mean().rename(columns={'value': 'averageValue'})

def aggregate_test_count_per_patient(df: pd.DataFrame) -> pd.DataFrame:
    return df.groupby('patientId', as_index=False).size().rename(columns={'size': 'testCount'})

def is_abnormal(df: pd.DataFrame) -> pd.Series:
    def check(row):
        try:
            if pd.isnull(row['value']) or not row['referenceRange'] or '-' not in row['referenceRange']:
                return False
            low, high = map(float, row['referenceRange'].split('-'))
            return row['value'] < low or row['value'] > high
        except Exception:
            return False
    return df.apply(check, axis=1)

def top_3_abnormal_tests(df: pd.DataFrame) -> pd.DataFrame:
    abnormals = df[is_abnormal(df)]
    return abnormals['testName'].value_counts().head(3).reset_index().rename(columns={'index': 'testName', 'testName': 'abnormalCount'})

def process_hl7_file(
    hl7_path: str,
    base_dir: str = "instrument-data"
) -> dict:
    """
    Orchestrates the HL7 file processing pipeline.
    Returns a dictionary of results.
    """
    df = parse_hl7_to_dataframe(hl7_path)
    if df.empty:
        print("No valid records found.")
        return {}
    # Store JSONs (idempotent)
    df.apply(lambda row: store_json_s3_style(row, base_dir=base_dir), axis=1)
    avg_obs = aggregate_average_observation_per_test_per_lab(df)
    test_counts = aggregate_test_count_per_patient(df)
    top_abnormals = top_3_abnormal_tests(df)
    return {
        "averageObservation": avg_obs,
        "testCounts": test_counts,
        "topAbnormalTests": top_abnormals
    }

def main():
    hl7_path = r"<>LBC_VM01_OUT_ORU_20240615_153000.txt"
    results = process_hl7_file(hl7_path)
    if not results:
        return
    print("Average Observation Value per Test per Lab:\n", results["averageObservation"])
    print("\nTest Count per Patient:\n", results["testCounts"])
    print("\nTop 3 Most Frequently Abnormal Tests:\n", results["topAbnormalTests"])

if __name__ == "__main__":
    main()

""" Alternatively, you can run this script with a command line argument for the HL7 file path:"""    
"""
def main():
    if len(sys.argv) < 2:
        print("Usage: python Untitled-2.py <hl7_file_path>")
        return
    hl7_path = sys.argv[1]
    results = process_hl7_file(hl7_path)
    if not results:
        return
    print("Average Observation Value per Test per Lab:\n", results["averageObservation"])
    print("\nTest Count per Patient:\n", results["testCounts"])
    print("\nTop 3 Most Frequently Abnormal Tests:\n", results["topAbnormalTests"])

if __name__ == "__main__":
    main()
"""