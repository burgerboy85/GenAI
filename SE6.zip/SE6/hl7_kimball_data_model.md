
# HL7 Laboratory Data Model (Kimball Style)

## Objective

To design a dimensional data model for HL7 laboratory test data that supports analytics, anomaly detection, and reporting with full auditability and extensibility.

---

##  Data Model Structure

### ✅ Grain Definition

> One row per patient lab test result (OBX segment), per test, per timestamp.

This granularity supports multiple observations per visit and enables trend analysis, anomaly detection, and record traceability.

---

## 🗂️ Tables

### 1. `fact_lab_test_results`
Fact table with one row per lab test observation per patient.

| Column | Description |
|--------|-------------|
| lab_test_sk | Surrogate key |
| patient_sk | FK to `dim_patient` |
| test_sk | FK to `dim_test` |
| lab_sk | FK to `dim_lab` |
| provider_sk | FK to `dim_provider` |
| location_sk | FK to `dim_location` |
| observation_datetime | Timestamp of test |
| message_datetime | HL7 message datetime |
| order_id | Order control ID |
| instrument_id | File source |
| value | Measured result |
| unit | Unit of measurement |
| reference_range_low | Ref low |
| reference_range_high | Ref high |
| abnormal_flag | HL7 flag (H/L/N) |
| abnormal_status | Derived flag |
| age_at_test | Calculated age |
| is_abnormal | Boolean |
| load_date | Ingestion date |
| record_source_file | HL7 source filename |

---

### 2. `dim_patient`

| Column | Description |
|--------|-------------|
| patient_sk | Surrogate key |
| patient_id | PID[3] |
| full_name | Normalized name |
| first_name / middle_name / last_name | Parsed fields |
| dob | Date of birth |
| gender | M/F |
| language | From PID[15] |
| address, city, state, zip, country | Location |
| phone | Contact |
| start_date / end_date | SCD tracking |
| current_flag | Active indicator |

---

### 3. `dim_test`

| Column | Description |
|--------|-------------|
| test_sk | Surrogate key |
| loinc_code | LOINC ID |
| test_name | Test type |
| default_unit | Unit |
| clinical_category | Derived |
| alert_low / high | Threshold |
| ref_low / high | Ref range |

---

### 4. `dim_lab`

| Column | Description |
|--------|-------------|
| lab_sk | Surrogate key |
| lab_id | MSH[3] |
| lab_name | Human-readable |
| source_system | MSH[4] |
| region | Derived |
| ingestion_method | HL7, API, etc. |

---

### 5. `dim_provider`

| Column | Description |
|--------|-------------|
| provider_sk | Surrogate key |
| provider_id | From OBR/PV1 |
| full_name | Parsed name |
| specialty | Optional |
| location | Optional |

---

### 6. `dim_location`

| Column | Description |
|--------|-------------|
| location_sk | Surrogate key |
| address, city, state, zip, country | Normalized |
| region | Grouping key |

---

### 7. `fact_abnormal_results`

Optional narrow table with just anomalies.

| Column | Description |
|--------|-------------|
| lab_test_sk | FK |
| severity | HIGH/LOW |
| reason | Derived from rules |
| alert_sent_flag | Boolean |
| processed_flag | Boolean |

---

## Use Cases Supported

| Requirement | Table(s) Used |
|-------------|---------------|
| Glucose trends per patient | `fact_lab_test_results + dim_patient + dim_test` |
| Abnormality tracking | `fact_abnormal_results` or derived |
| Patient counts by region | `dim_location + dim_patient` |
| Avg. test per lab | `fact_lab_test_results + dim_lab + dim_test` |
| Drilldowns by gender/test/doctor | All dimensions + fact |

---

##  Why This Works (Defensibility)

- ✅ **Atomic grain** enables detailed, accurate reporting.
- ✅ **Conforms to Kimball principles** with star schema clarity.
- ✅ **Extensible** — supports new tests, labs, patients.
- ✅ **Auditable** — track data lineage via `record_source_file`.
- ✅ **Compliant-ready** — allows field-level masking, SCD handling.
- ✅ **Powerful for BI** — enables aggregation, filtering, and slicing.

---

