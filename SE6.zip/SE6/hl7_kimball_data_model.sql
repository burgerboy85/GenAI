
-- Dimension: Patient
CREATE TABLE dim_patient (
    patient_sk INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id TEXT,
    full_name TEXT,
    first_name TEXT,
    middle_name TEXT,
    last_name TEXT,
    dob DATE,
    gender TEXT,
    language TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    zip TEXT,
    country TEXT,
    phone TEXT,
    start_date DATE,
    end_date DATE,
    current_flag BOOLEAN
);

-- Dimension: Test
CREATE TABLE dim_test (
    test_sk INTEGER PRIMARY KEY AUTOINCREMENT,
    loinc_code TEXT,
    test_name TEXT,
    default_unit TEXT,
    clinical_category TEXT,
    alert_low FLOAT,
    alert_high FLOAT,
    ref_low FLOAT,
    ref_high FLOAT
);

-- Dimension: Lab
CREATE TABLE dim_lab (
    lab_sk INTEGER PRIMARY KEY AUTOINCREMENT,
    lab_id TEXT,
    lab_name TEXT,
    source_system TEXT,
    region TEXT,
    ingestion_method TEXT
);

-- Dimension: Provider
CREATE TABLE dim_provider (
    provider_sk INTEGER PRIMARY KEY AUTOINCREMENT,
    provider_id TEXT,
    full_name TEXT,
    specialty TEXT,
    location TEXT
);

-- Dimension: Location
CREATE TABLE dim_location (
    location_sk INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT,
    city TEXT,
    state TEXT,
    zip TEXT,
    country TEXT,
    region TEXT
);

-- Fact: Lab Test Results
CREATE TABLE fact_lab_test_results (
    lab_test_sk INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_sk INTEGER,
    test_sk INTEGER,
    lab_sk INTEGER,
    provider_sk INTEGER,
    location_sk INTEGER,
    observation_datetime DATETIME,
    message_datetime DATETIME,
    order_id TEXT,
    instrument_id TEXT,
    value FLOAT,
    unit TEXT,
    reference_range_low FLOAT,
    reference_range_high FLOAT,
    abnormal_flag TEXT,
    abnormal_status TEXT,
    age_at_test INTEGER,
    is_abnormal BOOLEAN,
    load_date DATE,
    record_source_file TEXT,
    FOREIGN KEY(patient_sk) REFERENCES dim_patient(patient_sk),
    FOREIGN KEY(test_sk) REFERENCES dim_test(test_sk),
    FOREIGN KEY(lab_sk) REFERENCES dim_lab(lab_sk),
    FOREIGN KEY(provider_sk) REFERENCES dim_provider(provider_sk),
    FOREIGN KEY(location_sk) REFERENCES dim_location(location_sk)
);

-- Fact: Abnormal Results (optional derived fact)
CREATE TABLE fact_abnormal_results (
    lab_test_sk INTEGER,
    severity TEXT,
    reason TEXT,
    alert_sent_flag BOOLEAN,
    processed_flag BOOLEAN,
    FOREIGN KEY(lab_test_sk) REFERENCES fact_lab_test_results(lab_test_sk)
);
